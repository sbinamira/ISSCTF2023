def main():
    password = "retroCTF{"
    passw0rd = "1br3j13dt7ro__Cp6T4F_53a5ytw4h07er5ydcg_45ck3r1v4gfc0ukqb33sr6n_lv6578axdorje2vrtso193e825"
    userInput = input("Enter the password: ")
    #DO NOT CHANGE THE CODE ABOVE THIS LINE
    
    #TODO: Write your code here
    

    #DO NOT CHANGE ANYTHING BELOW THIS LINE
    if userInput[:-1].__eq__(password):
        print("Correct password!")
    else:
        print("Wrong password!")

if __name__ == "__main__":
    main()


"""
NOTE:
1. The password is in the form of retroCTF{...}
2. You must implement code that can manipulate the string passw0rd... try to google some python functions that can help you
3. Once you figure out step 2, you must figure out a way to concatenate the string passw0rd to the string password
"""